import axios from "axios";

export default axios.create({
  baseURL: "https://api.yelp.com/v3/businesses",
  headers: {
    Authorization:
      "Bearer uBLFeQeNpGqPM5WsqHAhRRhYG7TdifyF6skVsdAWKbrVE_VqnlCKgD-N8ejVg06HGaP0iAeof1n_svNTSaYB-630rGi4knkJcPsZ6m2T_Qwazhe2soW4qp2ZsDiwXHYx"
  }
});
