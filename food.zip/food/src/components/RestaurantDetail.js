import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet, FlatList, Image } from "react-native";
import yelp from "../api/yelp";

const RestaurantDetail = ({ navigation }) => {
  const id = navigation.getParam("id");
  const [restaurant, setRestaurant] = useState([]);
  const getResult = async id => {
    try {
      const response = await yelp.get(`/${id}`);
      setRestaurant(response.data);
      console.log(response.data);
    } catch (err) {}
  };
  useEffect(() => {
    getResult(id);
  }, []);
  return (
    <View style={{ flex: 1 }}>
      <View>
        {restaurant ? (
          <FlatList
            style={{ flexDirection: "row", marginLeft: 10, marginBottom: 15 }}
            horizontal
            showsHorizontalScrollIndicator={false}
            data={restaurant.photos}
            keyExtractor={result => result.id}
            renderItem={({ item }) => {
              return (
                <Image
                  source={{
                    uri: item
                  }}
                  style={styles.imageStyle}
                ></Image>
              );
            }}
          ></FlatList>
        ) : (
          <Text>No Record Found!</Text>
        )}
      </View>
      <View
        style={{
          flex: 1,
          marginHorizontal: 10
        }}
      >
        <Text style={{ fontSize: 22, fontWeight: "bold", marginBottom: 5 }}>
          {restaurant.name}
        </Text>
        <Text style={{ fontWeight: "400", marginBottom: 5 }}>
          Phone: {restaurant.phone}
        </Text>
        {restaurant.location ? (
          <Text style={{ fontWeight: "400", marginBottom: 5 }}>
            Address: {restaurant.location.display_address}
          </Text>
        ) : null}

        {restaurant.is_closed == false ? (
          <Text style={{ color: "green", fontSize: 16, fontWeight: "600" }}>
            Open
          </Text>
        ) : (
          <Text style={{ color: "red", fontSize: 16, fontWeight: "600" }}>
            Open
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  imageStyle: {
    width: 200,
    height: 150,
    borderRadius: 2,
    flex: 1
  }
});

export default RestaurantDetail;
