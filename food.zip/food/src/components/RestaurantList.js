import React from "react";
import { Text, View, StyleSheet, FlatList } from "react-native";
import SingleResult from "../components/SingleResult";
import { withNavigation } from "react-navigation";
import { TouchableOpacity } from "react-native-gesture-handler";

const RestaurantList = ({ title, priceResults, navigation }) => {
  return (
    <View>
      <Text style={styles.titleStyle}>{title}</Text>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={priceResults}
        keyExtractor={result => result.id}
        renderItem={({ item }) => {
          return (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("RestaurantDetail", {
                  id: item.id
                })
              }
            >
              <SingleResult singleItem={item}></SingleResult>
            </TouchableOpacity>
          );
        }}
      ></FlatList>
    </View>
  );
};

const styles = StyleSheet.create({
  titleStyle: {
    fontSize: 18,
    fontWeight: "bold",
    marginLeft: 15,
    marginBottom: 15
  }
});

export default withNavigation(RestaurantList);
