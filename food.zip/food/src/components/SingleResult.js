import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

export default SingleResult = ({ singleItem }) => {
  return (
    <View style={styles.conatiner}>
      {singleItem.image_url ? (
        <View>
          <Image
            style={{ width: 50, height: 50 }}
            source={{
              uri: singleItem.image_url
            }}
            style={styles.imageStyle}
          ></Image>
          <View
            style={{
              marginTop: 10,
              flex: 0.5,
              flexDirection: "column"
            }}
          >
            <Text style={styles.nameStyle}>{singleItem.name}</Text>
            <Text>
              {singleItem.rating} Stars, {singleItem.review_count} Reviews
            </Text>
          </View>
        </View>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  conatiner: {
    marginLeft: 15,
    marginBottom: 15
  },
  imageStyle: {
    width: 250,
    height: 150,
    borderRadius: 5
  },
  nameStyle: {
    fontSize: 14,
    fontWeight: "bold",
    flex: 0.8,
    flexWrap: "wrap"
  }
});
